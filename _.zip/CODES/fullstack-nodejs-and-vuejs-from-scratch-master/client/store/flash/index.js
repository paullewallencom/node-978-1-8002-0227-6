import mutations from './mutations'

export default {
    state: {
        messages: []
    },
    mutations
}
