<template>
    <img class="loader" src="/loading.png" alt="">
</template>
